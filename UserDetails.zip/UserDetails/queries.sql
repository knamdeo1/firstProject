create table userDetails(
user_id Number(5),
name varchar2(10),
age number(2),
mobile_number(10),
location varchar2(8)
);