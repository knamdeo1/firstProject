package com.cg.DBUtill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtill {
       public static Connection getConnection()
       throws ClassNotFoundException, SQLException
       {
    	   Class.forName("oracle.jdbc.driver.OracleDriver");
    	   Connection con =  DriverManager.getConnection("url","username","password");
    	   return con;
       }
}
