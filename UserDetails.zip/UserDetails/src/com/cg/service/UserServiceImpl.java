package com.cg.service;

import com.cg.bean.User;
import com.cg.dao.IUserDAO;
import com.cg.dao.UserDAOImpl;

public class UserServiceImpl implements IUserService
{
    IUserDAO iUserDAO = new UserDAOImpl();

	@Override
	public void addUser(User user) 
	{
	    iUserDAO.addUser(user);
	}

	@Override
	public User getUserById(int userId)
	{
		return iUserDAO.getUserById(userId);
		
	}

	@Override
	public User updateUser(User user) 
	{	
		return iUserDAO.updateUser(user);
	}

	@Override
	public void removeUserById(int userId) 
	{
	    iUserDAO.removeUserById(userId);
				
	}

}
