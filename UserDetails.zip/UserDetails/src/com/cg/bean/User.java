package com.cg.bean;

public class User 
{
	private int userId;
	private String Name;
	private int age;
	private long mobileNumber;
	private String location;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public User() {
		super();
	}
	public User(int userId, String name, int age, long mobileNumber, String location) {
		super();
		this.userId = userId;
		Name = name;
		this.age = age;
		this.mobileNumber = mobileNumber;
		this.location = location;
	}
	
	
	
	
	

}
