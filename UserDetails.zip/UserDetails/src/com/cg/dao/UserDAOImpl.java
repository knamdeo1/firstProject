package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.DBUtill.DBUtill;
import com.cg.bean.User;

public class UserDAOImpl implements  IUserDAO 
{

	@Override
	public void addUser(User user) 
	{
		try(Connection con = DBUtill.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("insert into userDetails values(?,?,?,?,?)");
			pstm.setInt(1, user.getUserId());
			pstm.setString(2, user.getName());
			pstm.setLong(3, user.getMobileNumber());
			pstm.setInt(4, user.getAge());
			pstm.setString(5, user.getLocation());
			
			pstm.execute();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	@Override
	public User getUserById(int userId) 
	{
		User user = null;
      try (Connection con = DBUtill.getConnection())
      {
			PreparedStatement pstm = con.prepareStatement("Select * from userDetails where userId = ?");
            pstm.setInt(1, userId);
            ResultSet res = pstm.executeQuery();
            if(res.next()== false)
            	System.out.println("No user found with this ID");
            
            user = new User();
            user.setUserId(res.getInt(1));
            user.setName(res.getString(2));
            user.setMobileNumber(res.getLong(3));
            user.setAge(res.getInt(4));
            user.setLocation(res.getString(5));
            
	} catch (Exception e) {
             System.out.println(e.getMessage());	
             }
		return user;
	}

	@Override
	public User updateUser(User user) 
	{
		try(Connection con = DBUtill.getConnection()) {
	
		    PreparedStatement pstm = con.prepareStatement("Update userDetails set user_name=?,mobile_number=?,age=?,location=? where userId=?");
		    
            pstm.setInt(5, user.getUserId());
            pstm.setString(1, user.getName());
            pstm.setLong(2, user.getMobileNumber());
            pstm.setInt(3, user.getAge());
            pstm.setString(4, user.getLocation());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			}
		
	            return user;
	}

	@Override
	public void removeUserById(int userId) {
		  User user = null;
	      try (Connection con = DBUtill.getConnection())
	      {
				PreparedStatement pstm = con.prepareStatement("Select * from userDetails where userId = ?");
	            pstm.setInt(1, userId);
	            ResultSet res = pstm.executeQuery();
	            if(res.next()== false)
	            	System.out.println("No user found with this ID");
	            
	            user = new User();
	            user.setUserId(res.getInt(1));
	            user.setName(res.getString(2));
	            user.setMobileNumber(res.getLong(3));
	            user.setAge(res.getInt(4));
	            user.setLocation(res.getString(5));
	            
	            PreparedStatement pstm1 = con.prepareStatement("delete from userDetails where id=?");
	            pstm1.setInt(1, userId);
	            pstm1.execute();
	      }
	      catch(Exception e){
	    	  System.out.println(e.getMessage());
	    	  }
	     
	      }

}
