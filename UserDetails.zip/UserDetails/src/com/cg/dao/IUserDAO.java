package com.cg.dao;

import com.cg.bean.User;

public interface IUserDAO
{
  public void addUser(User user);
  public User getUserById(int userId);
  public User updateUser(User user);
  public void removeUserById(int userId);
}
