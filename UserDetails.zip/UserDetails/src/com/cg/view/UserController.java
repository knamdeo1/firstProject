package com.cg.view;

import java.util.Scanner;

import com.cg.bean.User;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;

public class UserController {

	IUserService userService = new UserServiceImpl();
	Scanner sc = new Scanner(System.in);
	
	public void menu() {
	
		
		System.out.println("1.Add user details");
		System.out.println("2.delete user details");
		System.out.println("3.update user details");
		System.out.println("4.get user details");
		System.out.println("5.Exit.");
		
		int choice = sc.nextInt();
		operation(choice);
	}
	 
	private void operation(int choice) {
		switch(choice)	
		{
		case 1:addUser();
		       break;
		case 2:deleteUser();
	       break;
		case 3:updateUser();
	       break;
		case 4:getUser();
	       break;
		case 5:System.exit(0);
		break;
		default:System.out.println("enter valid choice");
		}
	}
	private void addUser() 
	{
		System.out.println("enter user id");
		int userId = sc.nextInt();
		System.out.println("enter user name");
		String name = sc.next();
		System.out.println("enter user mobile number");
		long mobileNumber = sc.nextLong();
		System.out.println("enter user age");
		int age = sc.nextInt();
		System.out.println("enter user location");
        String location = sc.next();
        User user = new User();
        
        user.setUserId(userId);
        user.setName(name);
        user.setMobileNumber(mobileNumber);
        user.setAge(age);
        user.setLocation(location);
		userService.addUser(user);
	}

	private void deleteUser() {
     System.out.println("Remove user Details");
     System.out.println("enter userId");
     int userId = sc.nextInt();
     try {
    	 userService.removeUserById(userId);
      }
     catch(Exception e)
     {
    	 System.out.println(e.getMessage());
     }
	}

	private void updateUser() {
		 System.out.println("\n Enter UserID you want to update");
	      int userId = sc.nextInt();
	      try {
	    	  User user = userService.getUserById(userId);
	    	  System.out.println("UserId" +user.getUserId());
	    	  System.out.println("User Name" +user.getName());
	    	  System.out.println("Mobile Number" +user.getMobileNumber());
	    	  System.out.println("Age" +user.getAge());
	    	  System.out.println("Location" +user.getLocation());
	    	  
	    	  System.out.println("Which field you want to update?");
	    	  System.out.println("1.User name");
	    	  System.out.println("2.Phone number");
	    	  System.out.println("3.Age");
	    	  System.out.println("4.Location");
	    	  int choice = sc.nextInt();
	  		  switch(choice)
	  		  {
	  		  	case 1:System.out.println("Enter new User Name");
	  		        String name = sc.next();
	  		        user.setName(name);
	  		  	case 2:System.out.println("Enter new User Phone Number");
		           long mobileNumber = sc.nextLong();
		           user.setMobileNumber(mobileNumber);
	  		  	case 3:System.out.println("Enter new User Age");
		           int age = sc.nextInt();
		           user.setAge(age);
	  		  	case 4:System.out.println("Enter new User Location");
		           String location = sc.next();
		           user.setLocation(location);
	  		  }
	  		 userService.updateUser(user);
	         }
	      catch(Exception e)
	      {
	    	  System.out.println(e.getMessage());
	      }
	}

	private void getUser() {
      System.out.println("Get User Details");
      System.out.println("\n Enter UserID");
      int userId = sc.nextInt();
      try {
    	  User user = userService.getUserById(userId);
    	  System.out.println("UserId" +user.getUserId());
    	  System.out.println("User Name" +user.getName());
    	  System.out.println("Mobile Number" +user.getMobileNumber());
    	  System.out.println("Age" +user.getAge());
    	  System.out.println("Location" +user.getLocation());
         }
      catch(Exception e)
      {
    	  System.out.println(e.getMessage());
      }
	}
	
	
	public static void main(String[] args) 
	{
		
		UserController userCtrl = new UserController();
		while(true)
		{
		userCtrl.menu();
		}
	}

}
